#!/bin/bash
echo "TEST" > /tmp/test-remote-exec